export type StreamProtocol = 'rtmp' | 'rtsp';

export interface StreamConfig {
  id: string;
  name: string;
  sourceUrl: string;
  sourceProtocol: StreamProtocol;
  targetProtocol: StreamProtocol;
  targetUrl?: string;
  status: 'idle' | 'converting' | 'active' | 'error';
  createdAt: Date;
  lastActive?: Date;
  error?: string;
}

export interface StreamStats {
  id: string;
  streamId: string;
  bitrate: number;
  fps: number;
  resolution: string;
  audioChannels: number;
  audioSampleRate: number;
  uptime: number;
  dataTransferred: number;
  timestamp: Date;
}

export interface ConversionSettings {
  videoBitrate: number;
  audioBitrate: number;
  videoCodec: string;
  audioCodec: string;
  resolution: string;
  framerate: number;
  keyframeInterval: number;
}