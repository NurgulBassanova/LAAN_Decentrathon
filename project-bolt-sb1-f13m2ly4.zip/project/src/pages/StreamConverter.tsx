import React, { useState } from 'react';
import { Play, X, CheckCircle, Link, Save } from 'lucide-react';
import { StreamProtocol } from '../types/stream';
import { mockStreams } from '../utils/mockData';

const StreamConverter: React.FC = () => {
  const [sourceUrl, setSourceUrl] = useState('');
  const [sourceProtocol, setSourceProtocol] = useState<StreamProtocol>('rtmp');
  const [targetProtocol, setTargetProtocol] = useState<StreamProtocol>('rtsp');
  const [streamName, setStreamName] = useState('');
  const [isAdvancedOpen, setIsAdvancedOpen] = useState(false);
  const [isConverting, setIsConverting] = useState(false);
  const [conversionComplete, setConversionComplete] = useState(false);
  const [targetUrl, setTargetUrl] = useState('');
  
  const handleConvert = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!sourceUrl || !streamName) return;
    
    setIsConverting(true);
    
    // Mock conversion process
    setTimeout(() => {
      setIsConverting(false);
      setConversionComplete(true);
      
      // Generate a mock target URL
      const mockTarget = targetProtocol === 'rtmp' 
        ? `rtmp://stream.example.com/live/${streamName.toLowerCase().replace(/\s+/g, '-')}`
        : `rtsp://stream.example.com:8554/live/${streamName.toLowerCase().replace(/\s+/g, '-')}`;
      
      setTargetUrl(mockTarget);
    }, 3000);
  };
  
  const handleReset = () => {
    setSourceUrl('');
    setStreamName('');
    setConversionComplete(false);
    setTargetUrl('');
  };
  
  const handleCopyUrl = () => {
    if (targetUrl) {
      navigator.clipboard.writeText(targetUrl);
      // In a real app, we'd show a toast notification here
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Stream Converter</h1>
      
      <div className="bg-gray-800 rounded-lg overflow-hidden">
        <div className="p-6">
          {!conversionComplete ? (
            <form onSubmit={handleConvert}>
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Stream Name
                  </label>
                  <input
                    type="text"
                    value={streamName}
                    onChange={(e) => setStreamName(e.target.value)}
                    placeholder="My Live Stream"
                    className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Source Stream URL
                  </label>
                  <div className="flex">
                    <div className="relative flex-1">
                      <input
                        type="text"
                        value={sourceUrl}
                        onChange={(e) => setSourceUrl(e.target.value)}
                        placeholder={sourceProtocol === 'rtmp' ? 'rtmp://source.example.com/live/stream' : 'rtsp://source.example.com:8554/stream'}
                        className="w-full bg-gray-700 border border-gray-600 rounded-l-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                        required
                      />
                      {sourceUrl && (
                        <button
                          type="button"
                          onClick={() => setSourceUrl('')}
                          className="absolute right-2 top-1/2 transform -translate-y-1/2"
                        >
                          <X className="h-4 w-4 text-gray-400 hover:text-white" />
                        </button>
                      )}
                    </div>
                    <select
                      value={sourceProtocol}
                      onChange={(e) => setSourceProtocol(e.target.value as StreamProtocol)}
                      className="bg-gray-700 border-l-0 border border-gray-600 rounded-r-lg py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="rtmp">RTMP</option>
                      <option value="rtsp">RTSP</option>
                    </select>
                  </div>
                  <p className="mt-1 text-xs text-gray-400">
                    Enter the complete URL including the protocol
                  </p>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Target Protocol
                  </label>
                  <div className="flex space-x-4">
                    <label className="flex items-center">
                      <input
                        type="radio"
                        value="rtmp"
                        checked={targetProtocol === 'rtmp'}
                        onChange={() => setTargetProtocol('rtmp')}
                        className="h-4 w-4 text-blue-500 focus:ring-blue-500 border-gray-600 bg-gray-700"
                      />
                      <span className="ml-2 text-white">RTMP</span>
                    </label>
                    <label className="flex items-center">
                      <input
                        type="radio"
                        value="rtsp"
                        checked={targetProtocol === 'rtsp'}
                        onChange={() => setTargetProtocol('rtsp')}
                        className="h-4 w-4 text-blue-500 focus:ring-blue-500 border-gray-600 bg-gray-700"
                      />
                      <span className="ml-2 text-white">RTSP</span>
                    </label>
                  </div>
                </div>
                
                <div>
                  <button
                    type="button"
                    onClick={() => setIsAdvancedOpen(!isAdvancedOpen)}
                    className="text-sm text-blue-400 hover:text-blue-300 flex items-center"
                  >
                    {isAdvancedOpen ? 'Hide' : 'Show'} Advanced Settings
                    <svg
                      className={`ml-1 h-4 w-4 transform transition-transform ${isAdvancedOpen ? 'rotate-180' : ''}`}
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                  
                  {isAdvancedOpen && (
                    <div className="mt-4 bg-gray-750 p-4 rounded-lg border border-gray-700 grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1">
                          Video Codec
                        </label>
                        <select className="w-full bg-gray-700 border border-gray-600 rounded py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                          <option value="h264">H.264</option>
                          <option value="h265">H.265 (HEVC)</option>
                          <option value="vp9">VP9</option>
                        </select>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1">
                          Audio Codec
                        </label>
                        <select className="w-full bg-gray-700 border border-gray-600 rounded py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                          <option value="aac">AAC</option>
                          <option value="mp3">MP3</option>
                          <option value="opus">Opus</option>
                        </select>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1">
                          Video Bitrate
                        </label>
                        <select className="w-full bg-gray-700 border border-gray-600 rounded py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                          <option value="original">Original (passthrough)</option>
                          <option value="2500">2500 kbps</option>
                          <option value="4000">4000 kbps</option>
                          <option value="6000">6000 kbps</option>
                        </select>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1">
                          Audio Bitrate
                        </label>
                        <select className="w-full bg-gray-700 border border-gray-600 rounded py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                          <option value="original">Original (passthrough)</option>
                          <option value="128">128 kbps</option>
                          <option value="192">192 kbps</option>
                          <option value="256">256 kbps</option>
                        </select>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1">
                          Resolution
                        </label>
                        <select className="w-full bg-gray-700 border border-gray-600 rounded py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                          <option value="original">Original (passthrough)</option>
                          <option value="720p">720p (1280x720)</option>
                          <option value="1080p">1080p (1920x1080)</option>
                          <option value="1440p">1440p (2560x1440)</option>
                        </select>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1">
                          Framerate
                        </label>
                        <select className="w-full bg-gray-700 border border-gray-600 rounded py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                          <option value="original">Original (passthrough)</option>
                          <option value="30">30 FPS</option>
                          <option value="60">60 FPS</option>
                        </select>
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="flex justify-end">
                  <button
                    type="submit"
                    className={`flex items-center px-4 py-2 bg-blue-600 rounded-lg text-white font-medium hover:bg-blue-700 transition-colors ${
                      isConverting ? 'opacity-75 cursor-not-allowed' : ''
                    }`}
                    disabled={isConverting || !sourceUrl || !streamName}
                  >
                    {isConverting ? (
                      <>
                        <div className="mr-2 h-4 w-4 rounded-full border-2 border-white border-t-transparent animate-spin"></div>
                        Converting...
                      </>
                    ) : (
                      <>
                        <Play className="mr-2 h-4 w-4" />
                        Start Conversion
                      </>
                    )}
                  </button>
                </div>
              </div>
            </form>
          ) : (
            <div className="space-y-6">
              <div className="flex items-center bg-green-900/20 border border-green-900 text-green-400 p-4 rounded-lg">
                <CheckCircle className="h-6 w-6 mr-2" />
                <div>
                  <p className="font-medium">Conversion Successful!</p>
                  <p className="text-sm">Your stream is now ready to use.</p>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-medium mb-2">Stream Details</h3>
                <div className="bg-gray-850 rounded-lg p-4 space-y-4">
                  <div>
                    <div className="text-sm text-gray-400 mb-1">Stream Name</div>
                    <div className="font-medium">{streamName}</div>
                  </div>
                  
                  <div>
                    <div className="text-sm text-gray-400 mb-1">Source URL ({sourceProtocol.toUpperCase()})</div>
                    <div className="bg-gray-900 p-2 rounded font-mono text-sm overflow-x-auto">
                      {sourceUrl}
                    </div>
                  </div>
                  
                  <div>
                    <div className="text-sm text-gray-400 mb-1">Target URL ({targetProtocol.toUpperCase()})</div>
                    <div className="bg-gray-900 p-2 rounded font-mono text-sm overflow-x-auto relative group">
                      <div className="pr-8">{targetUrl}</div>
                      <button 
                        onClick={handleCopyUrl} 
                        className="absolute right-2 top-1/2 transform -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Copy className="h-4 w-4 text-blue-400 hover:text-blue-300" />
                      </button>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                    <div className="bg-gray-700 p-2 rounded">
                      <div className="text-xs text-gray-400">Status</div>
                      <div className="font-medium text-green-400">Active</div>
                    </div>
                    <div className="bg-gray-700 p-2 rounded">
                      <div className="text-xs text-gray-400">Bitrate</div>
                      <div className="font-medium">3.2 Mbps</div>
                    </div>
                    <div className="bg-gray-700 p-2 rounded">
                      <div className="text-xs text-gray-400">Resolution</div>
                      <div className="font-medium">1080p</div>
                    </div>
                    <div className="bg-gray-700 p-2 rounded">
                      <div className="text-xs text-gray-400">FPS</div>
                      <div className="font-medium">30</div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex justify-between">
                <button
                  onClick={handleReset}
                  className="px-4 py-2 bg-gray-700 rounded-lg text-white font-medium hover:bg-gray-600 transition-colors"
                >
                  Convert Another Stream
                </button>
                
                <div className="flex space-x-2">
                  <button className="flex items-center px-4 py-2 bg-blue-600 rounded-lg text-white font-medium hover:bg-blue-700 transition-colors">
                    <Link className="mr-2 h-4 w-4" />
                    View Stream
                  </button>
                  <button className="flex items-center px-4 py-2 bg-green-600 rounded-lg text-white font-medium hover:bg-green-700 transition-colors">
                    <Save className="mr-2 h-4 w-4" />
                    Save Stream
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
      
      <div className="mt-8">
        <h2 className="text-lg font-medium mb-4">Recently Converted Streams</h2>
        <div className="bg-gray-800 rounded-lg overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-700">
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-300">Name</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-300">Source</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-300">Target</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-300">Status</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-300">Created</th>
                <th className="px-4 py-3 text-right text-sm font-medium text-gray-300">Actions</th>
              </tr>
            </thead>
            <tbody>
              {mockStreams.slice(0, 3).map((stream) => (
                <tr key={stream.id} className="border-b border-gray-700 hover:bg-gray-750">
                  <td className="px-4 py-3 text-sm">{stream.name}</td>
                  <td className="px-4 py-3 text-sm">{stream.sourceProtocol.toUpperCase()}</td>
                  <td className="px-4 py-3 text-sm">{stream.targetProtocol.toUpperCase()}</td>
                  <td className="px-4 py-3 text-sm">
                    {stream.status === 'active' && <span className="text-green-400">Active</span>}
                    {stream.status === 'idle' && <span className="text-gray-400">Idle</span>}
                    {stream.status === 'converting' && <span className="text-blue-400">Converting</span>}
                    {stream.status === 'error' && <span className="text-red-400">Error</span>}
                  </td>
                  <td className="px-4 py-3 text-sm">{stream.createdAt.toLocaleDateString()}</td>
                  <td className="px-4 py-3 text-sm text-right">
                    <button className="text-blue-400 hover:text-blue-300 mr-2">Edit</button>
                    <button className="text-red-400 hover:text-red-300">Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default StreamConverter;