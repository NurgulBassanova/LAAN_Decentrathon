import React from 'react';
import { BarChart3, Activity, ArrowUpRight, ArrowDownRight, Cpu, Server } from 'lucide-react';
import StreamStatusCard from '../components/StreamStatusCard';
import { StreamConfig } from '../types/stream';
import { mockStreams } from '../utils/mockData';

const Dashboard: React.FC = () => {
  const activeStreams = mockStreams.filter(stream => stream.status === 'active' || stream.status === 'converting');
  
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <div className="text-sm text-gray-400">
          Last updated: {new Date().toLocaleTimeString()}
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          title="Active Streams" 
          value={activeStreams.length.toString()}
          icon={<BarChart3 className="h-5 w-5 text-blue-400" />}
          change={"+2"} 
          isPositive={true} 
        />
        <StatCard 
          title="CPU Usage" 
          value="42%" 
          icon={<Cpu className="h-5 w-5 text-purple-400" />}
          change={"-5%"} 
          isPositive={true} 
        />
        <StatCard 
          title="Bandwidth" 
          value="28.5 Mbps" 
          icon={<Activity className="h-5 w-5 text-green-400" />}
          change={"+4.2 Mbps"} 
          isPositive={false} 
        />
        <StatCard 
          title="Server Health" 
          value="Excellent" 
          icon={<Server className="h-5 w-5 text-teal-400" />}
          change={"Stable"} 
          isPositive={true} 
        />
      </div>
      
      <div className="bg-gray-800 rounded-lg p-4">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-medium">Active Streams</h2>
          <button className="text-sm text-blue-400 hover:text-blue-300 transition-colors">
            View All
          </button>
        </div>
        
        <div className="space-y-4">
          {activeStreams.length > 0 ? (
            activeStreams.map(stream => (
              <StreamStatusCard key={stream.id} stream={stream} />
            ))
          ) : (
            <div className="text-center p-6 text-gray-500">
              No active streams. Start a conversion to see streams here.
            </div>
          )}
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-gray-800 rounded-lg p-4">
          <h2 className="text-lg font-medium mb-3">Server Load</h2>
          <div className="h-48 flex items-end">
            {/* Mocked chart bars */}
            {[45, 60, 30, 70, 50, 80, 65].map((height, i) => (
              <div key={i} className="flex-1 mx-1">
                <div 
                  className="bg-gradient-to-t from-blue-600 to-blue-400 rounded-t" 
                  style={{ height: `${height}%` }}
                ></div>
                <div className="text-xs text-gray-500 text-center mt-1">
                  {i + 1}h
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="bg-gray-800 rounded-lg p-4">
          <h2 className="text-lg font-medium mb-3">Protocol Distribution</h2>
          <div className="flex h-48 items-center justify-center">
            <div className="relative w-40 h-40">
              {/* Mock donut chart with gradient */}
              <div className="absolute inset-0 rounded-full border-8 border-purple-500 opacity-30"></div>
              <div 
                className="absolute inset-0 rounded-full border-8 border-transparent border-t-blue-500 border-r-blue-500 border-b-blue-500" 
                style={{ transform: 'rotate(45deg)' }}
              ></div>
              <div className="absolute inset-0 flex items-center justify-center flex-col">
                <span className="text-2xl font-bold">65%</span>
                <span className="text-xs text-gray-400">RTMP</span>
              </div>
            </div>
            <div className="ml-4">
              <div className="flex items-center mb-2">
                <div className="w-3 h-3 rounded-full bg-blue-500 mr-2"></div>
                <span className="text-sm">RTMP (65%)</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 rounded-full bg-purple-500 mr-2"></div>
                <span className="text-sm">RTSP (35%)</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

interface StatCardProps {
  title: string;
  value: string;
  icon: React.ReactNode;
  change: string;
  isPositive: boolean;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon, change, isPositive }) => {
  return (
    <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
      <div className="flex justify-between items-start">
        <div>
          <p className="text-sm text-gray-400">{title}</p>
          <p className="text-2xl font-bold mt-1">{value}</p>
        </div>
        <div className="p-2 bg-gray-700 rounded-lg">
          {icon}
        </div>
      </div>
      <div className="mt-4 flex items-center">
        {isPositive ? (
          <ArrowUpRight className="h-4 w-4 text-green-400 mr-1" />
        ) : (
          <ArrowDownRight className="h-4 w-4 text-red-400 mr-1" />
        )}
        <span className={`text-sm ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
          {change}
        </span>
      </div>
    </div>
  );
};

export default Dashboard;