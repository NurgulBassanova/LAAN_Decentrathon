import React, { useState } from 'react';
import { Save, Cpu, Network, Shield, Database, Monitor, RefreshCw } from 'lucide-react';

const Settings: React.FC = () => {
  const [activeTab, setActiveTab] = useState('server');
  
  const renderTabContent = () => {
    switch (activeTab) {
      case 'server':
        return <ServerSettings />;
      case 'conversion':
        return <ConversionSettings />;
      case 'security':
        return <SecuritySettings />;
      case 'storage':
        return <StorageSettings />;
      case 'monitoring':
        return <MonitoringSettings />;
      default:
        return <ServerSettings />;
    }
  };
  
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Settings</h1>
      
      <div className="bg-gray-800 rounded-lg overflow-hidden">
        <div className="flex border-b border-gray-700">
          <button
            className={`px-4 py-3 text-sm font-medium flex items-center ${
              activeTab === 'server' 
                ? 'text-blue-400 border-b-2 border-blue-400' 
                : 'text-gray-400 hover:text-white'
            }`}
            onClick={() => setActiveTab('server')}
          >
            <Cpu className="mr-2 h-4 w-4" />
            Server
          </button>
          <button
            className={`px-4 py-3 text-sm font-medium flex items-center ${
              activeTab === 'conversion' 
                ? 'text-blue-400 border-b-2 border-blue-400' 
                : 'text-gray-400 hover:text-white'
            }`}
            onClick={() => setActiveTab('conversion')}
          >
            <RefreshCw className="mr-2 h-4 w-4" />
            Conversion
          </button>
          <button
            className={`px-4 py-3 text-sm font-medium flex items-center ${
              activeTab === 'security' 
                ? 'text-blue-400 border-b-2 border-blue-400' 
                : 'text-gray-400 hover:text-white'
            }`}
            onClick={() => setActiveTab('security')}
          >
            <Shield className="mr-2 h-4 w-4" />
            Security
          </button>
          <button
            className={`px-4 py-3 text-sm font-medium flex items-center ${
              activeTab === 'storage' 
                ? 'text-blue-400 border-b-2 border-blue-400' 
                : 'text-gray-400 hover:text-white'
            }`}
            onClick={() => setActiveTab('storage')}
          >
            <Database className="mr-2 h-4 w-4" />
            Storage
          </button>
          <button
            className={`px-4 py-3 text-sm font-medium flex items-center ${
              activeTab === 'monitoring' 
                ? 'text-blue-400 border-b-2 border-blue-400' 
                : 'text-gray-400 hover:text-white'
            }`}
            onClick={() => setActiveTab('monitoring')}
          >
            <Monitor className="mr-2 h-4 w-4" />
            Monitoring
          </button>
        </div>
        
        <div className="p-6">
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
};

const ServerSettings: React.FC = () => {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-medium mb-4">Server Configuration</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Server Name
            </label>
            <input
              type="text"
              defaultValue="StreamFlow-Main"
              className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Server Location
            </label>
            <select className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="us-east">US East (N. Virginia)</option>
              <option value="us-west">US West (Oregon)</option>
              <option value="eu-central">EU Central (Frankfurt)</option>
              <option value="ap-southeast">Asia Pacific (Singapore)</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              RTMP Port
            </label>
            <input
              type="number"
              defaultValue="1935"
              className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <p className="mt-1 text-xs text-gray-400">
              Standard RTMP port is 1935
            </p>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              RTSP Port
            </label>
            <input
              type="number"
              defaultValue="8554"
              className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <p className="mt-1 text-xs text-gray-400">
              Standard RTSP port is 8554
            </p>
          </div>
        </div>
      </div>
      
      <div>
        <h2 className="text-lg font-medium mb-4">Resource Allocation</h2>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              CPU Usage Limit
            </label>
            <div className="flex items-center">
              <input
                type="range"
                min="10"
                max="100"
                defaultValue="75"
                className="flex-1 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
              />
              <span className="ml-3 text-sm font-medium">75%</span>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Memory Usage Limit
            </label>
            <div className="flex items-center">
              <input
                type="range"
                min="256"
                max="8192"
                step="256"
                defaultValue="4096"
                className="flex-1 h-2 bg-gray-700 rounded-lg appearance-none cursor-pointer"
              />
              <span className="ml-3 text-sm font-medium">4GB</span>
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Maximum Concurrent Streams
            </label>
            <select className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="5">5 streams</option>
              <option value="10">10 streams</option>
              <option value="25">25 streams</option>
              <option value="50">50 streams</option>
              <option value="100">100 streams</option>
            </select>
          </div>
        </div>
      </div>
      
      <div className="flex justify-end">
        <button className="flex items-center px-4 py-2 bg-blue-600 rounded-lg text-white font-medium hover:bg-blue-700 transition-colors">
          <Save className="mr-2 h-4 w-4" />
          Save Changes
        </button>
      </div>
    </div>
  );
};

const ConversionSettings: React.FC = () => {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-medium mb-4">Default Conversion Settings</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Default Video Codec
            </label>
            <select className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="h264">H.264 (AVC)</option>
              <option value="h265">H.265 (HEVC)</option>
              <option value="vp9">VP9</option>
              <option value="av1">AV1</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Default Audio Codec
            </label>
            <select className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="aac">AAC</option>
              <option value="mp3">MP3</option>
              <option value="opus">Opus</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Default Video Bitrate
            </label>
            <select className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="passthrough">Original (passthrough)</option>
              <option value="2500">2500 kbps</option>
              <option value="4000">4000 kbps</option>
              <option value="6000">6000 kbps</option>
              <option value="8000">8000 kbps</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Default Audio Bitrate
            </label>
            <select className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="passthrough">Original (passthrough)</option>
              <option value="128">128 kbps</option>
              <option value="192">192 kbps</option>
              <option value="256">256 kbps</option>
              <option value="320">320 kbps</option>
            </select>
          </div>
        </div>
      </div>
      
      <div>
        <h2 className="text-lg font-medium mb-4">Advanced Settings</h2>
        
        <div className="space-y-4">
          <div className="flex items-center">
            <input
              id="hardware-acceleration"
              type="checkbox"
              defaultChecked
              className="h-4 w-4 text-blue-600 rounded border-gray-600 focus:ring-blue-500 bg-gray-700"
            />
            <label htmlFor="hardware-acceleration" className="ml-2 text-sm text-gray-300">
              Enable hardware acceleration (when available)
            </label>
          </div>
          
          <div className="flex items-center">
            <input
              id="preserve-metadata"
              type="checkbox"
              defaultChecked
              className="h-4 w-4 text-blue-600 rounded border-gray-600 focus:ring-blue-500 bg-gray-700"
            />
            <label htmlFor="preserve-metadata" className="ml-2 text-sm text-gray-300">
              Preserve stream metadata during conversion
            </label>
          </div>
          
          <div className="flex items-center">
            <input
              id="auto-reconnect"
              type="checkbox"
              defaultChecked
              className="h-4 w-4 text-blue-600 rounded border-gray-600 focus:ring-blue-500 bg-gray-700"
            />
            <label htmlFor="auto-reconnect" className="ml-2 text-sm text-gray-300">
              Automatically reconnect to source on disconnect
            </label>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Buffer Size (seconds)
            </label>
            <input
              type="number"
              defaultValue="5"
              min="1"
              max="60"
              className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <p className="mt-1 text-xs text-gray-400">
              Larger buffer increases stability but adds latency
            </p>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Thread Count
            </label>
            <select className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="auto">Auto (based on CPU cores)</option>
              <option value="1">1 thread</option>
              <option value="2">2 threads</option>
              <option value="4">4 threads</option>
              <option value="8">8 threads</option>
            </select>
          </div>
        </div>
      </div>
      
      <div className="flex justify-end">
        <button className="flex items-center px-4 py-2 bg-blue-600 rounded-lg text-white font-medium hover:bg-blue-700 transition-colors">
          <Save className="mr-2 h-4 w-4" />
          Save Changes
        </button>
      </div>
    </div>
  );
};

const SecuritySettings: React.FC = () => {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-medium mb-4">Authentication</h2>
        
        <div className="space-y-4">
          <div className="flex items-center">
            <input
              id="require-auth"
              type="checkbox"
              defaultChecked
              className="h-4 w-4 text-blue-600 rounded border-gray-600 focus:ring-blue-500 bg-gray-700"
            />
            <label htmlFor="require-auth" className="ml-2 text-sm text-gray-300">
              Require authentication for stream access
            </label>
          </div>
          
          <div className="flex items-center">
            <input
              id="stream-keys"
              type="checkbox"
              defaultChecked
              className="h-4 w-4 text-blue-600 rounded border-gray-600 focus:ring-blue-500 bg-gray-700"
            />
            <label htmlFor="stream-keys" className="ml-2 text-sm text-gray-300">
              Use stream keys for publisher authentication
            </label>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Authentication Method
            </label>
            <select className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="basic">Basic Authentication</option>
              <option value="digest">Digest Authentication</option>
              <option value="token">Token-based Authentication</option>
              <option value="oauth">OAuth 2.0</option>
            </select>
          </div>
        </div>
      </div>
      
      <div>
        <h2 className="text-lg font-medium mb-4">Access Control</h2>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              IP Restrictions
            </label>
            <textarea
              placeholder="Enter IP addresses or CIDR ranges, one per line"
              className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 h-24 resize-none"
            ></textarea>
            <p className="mt-1 text-xs text-gray-400">
              Leave empty to allow all IP addresses
            </p>
          </div>
          
          <div className="flex items-center">
            <input
              id="cors"
              type="checkbox"
              defaultChecked
              className="h-4 w-4 text-blue-600 rounded border-gray-600 focus:ring-blue-500 bg-gray-700"
            />
            <label htmlFor="cors" className="ml-2 text-sm text-gray-300">
              Enable CORS (Cross-Origin Resource Sharing)
            </label>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Allowed Origins
            </label>
            <input
              type="text"
              defaultValue="*"
              placeholder="https://example.com, https://app.example.com"
              className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <p className="mt-1 text-xs text-gray-400">
              Use * to allow all origins, or specify domains separated by commas
            </p>
          </div>
        </div>
      </div>
      
      <div>
        <h2 className="text-lg font-medium mb-4">Encryption</h2>
        
        <div className="space-y-4">
          <div className="flex items-center">
            <input
              id="ssl-rtmp"
              type="checkbox"
              defaultChecked
              className="h-4 w-4 text-blue-600 rounded border-gray-600 focus:ring-blue-500 bg-gray-700"
            />
            <label htmlFor="ssl-rtmp" className="ml-2 text-sm text-gray-300">
              Enable RTMPS (RTMP over SSL/TLS)
            </label>
          </div>
          
          <div className="flex items-center">
            <input
              id="ssl-rtsp"
              type="checkbox"
              defaultChecked
              className="h-4 w-4 text-blue-600 rounded border-gray-600 focus:ring-blue-500 bg-gray-700"
            />
            <label htmlFor="ssl-rtsp" className="ml-2 text-sm text-gray-300">
              Enable RTSPS (RTSP over SSL/TLS)
            </label>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              SSL Certificate Path
            </label>
            <input
              type="text"
              placeholder="/path/to/certificate.pem"
              className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              SSL Key Path
            </label>
            <input
              type="text"
              placeholder="/path/to/private.key"
              className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>
      
      <div className="flex justify-end">
        <button className="flex items-center px-4 py-2 bg-blue-600 rounded-lg text-white font-medium hover:bg-blue-700 transition-colors">
          <Save className="mr-2 h-4 w-4" />
          Save Changes
        </button>
      </div>
    </div>
  );
};

const StorageSettings: React.FC = () => {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-medium mb-4">Stream Recording</h2>
        
        <div className="space-y-4">
          <div className="flex items-center">
            <input
              id="record-streams"
              type="checkbox"
              className="h-4 w-4 text-blue-600 rounded border-gray-600 focus:ring-blue-500 bg-gray-700"
            />
            <label htmlFor="record-streams" className="ml-2 text-sm text-gray-300">
              Automatically record all streams
            </label>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Recording Format
            </label>
            <select className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="mp4">MP4</option>
              <option value="flv">FLV</option>
              <option value="ts">MPEG-TS</option>
              <option value="hls">HLS</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Storage Path
            </label>
            <input
              type="text"
              defaultValue="/var/recordings"
              className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              File Naming Pattern
            </label>
            <input
              type="text"
              defaultValue="{stream_name}_{datetime}"
              className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <p className="mt-1 text-xs text-gray-400">
              Available variables: {'{stream_name}'}, {'{datetime}'}, {'{protocol}'}, {'{quality}'}
            </p>
          </div>
        </div>
      </div>
      
      <div>
        <h2 className="text-lg font-medium mb-4">Storage Management</h2>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Storage Quota
            </label>
            <select className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="unlimited">Unlimited</option>
              <option value="10">10 GB</option>
              <option value="50">50 GB</option>
              <option value="100">100 GB</option>
              <option value="500">500 GB</option>
              <option value="1000">1 TB</option>
            </select>
          </div>
          
          <div className="flex items-center">
            <input
              id="auto-delete"
              type="checkbox"
              className="h-4 w-4 text-blue-600 rounded border-gray-600 focus:ring-blue-500 bg-gray-700"
            />
            <label htmlFor="auto-delete" className="ml-2 text-sm text-gray-300">
              Automatically delete old recordings
            </label>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Keep Recordings For
            </label>
            <select className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="1">1 day</option>
              <option value="7">7 days</option>
              <option value="30">30 days</option>
              <option value="90">90 days</option>
              <option value="365">1 year</option>
            </select>
          </div>
        </div>
      </div>
      
      <div>
        <h2 className="text-lg font-medium mb-4">External Storage</h2>
        
        <div className="space-y-4">
          <div className="flex items-center">
            <input
              id="use-external"
              type="checkbox"
              className="h-4 w-4 text-blue-600 rounded border-gray-600 focus:ring-blue-500 bg-gray-700"
            />
            <label htmlFor="use-external" className="ml-2 text-sm text-gray-300">
              Use external storage for recordings
            </label>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Storage Provider
            </label>
            <select className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="s3">Amazon S3</option>
              <option value="gcs">Google Cloud Storage</option>
              <option value="azure">Azure Blob Storage</option>
              <option value="ftp">FTP Server</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Bucket / Container Name
            </label>
            <input
              type="text"
              placeholder="my-stream-recordings"
              className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Access Key / Connection String
            </label>
            <input
              type="password"
              placeholder="••••••••••••••••••••••"
              className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>
      
      <div className="flex justify-end">
        <button className="flex items-center px-4 py-2 bg-blue-600 rounded-lg text-white font-medium hover:bg-blue-700 transition-colors">
          <Save className="mr-2 h-4 w-4" />
          Save Changes
        </button>
      </div>
    </div>
  );
};

const MonitoringSettings: React.FC = () => {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-medium mb-4">Health Monitoring</h2>
        
        <div className="space-y-4">
          <div className="flex items-center">
            <input
              id="health-check"
              type="checkbox"
              defaultChecked
              className="h-4 w-4 text-blue-600 rounded border-gray-600 focus:ring-blue-500 bg-gray-700"
            />
            <label htmlFor="health-check" className="ml-2 text-sm text-gray-300">
              Enable stream health checks
            </label>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Health Check Interval (seconds)
            </label>
            <input
              type="number"
              defaultValue="30"
              min="5"
              max="300"
              className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          <div className="flex items-center">
            <input
              id="auto-restart"
              type="checkbox"
              defaultChecked
              className="h-4 w-4 text-blue-600 rounded border-gray-600 focus:ring-blue-500 bg-gray-700"
            />
            <label htmlFor="auto-restart" className="ml-2 text-sm text-gray-300">
              Automatically restart failed streams
            </label>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Max Restart Attempts
            </label>
            <input
              type="number"
              defaultValue="3"
              min="1"
              max="10"
              className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>
      
      <div>
        <h2 className="text-lg font-medium mb-4">Notifications</h2>
        
        <div className="space-y-4">
          <div className="flex items-center">
            <input
              id="email-alerts"
              type="checkbox"
              className="h-4 w-4 text-blue-600 rounded border-gray-600 focus:ring-blue-500 bg-gray-700"
            />
            <label htmlFor="email-alerts" className="ml-2 text-sm text-gray-300">
              Enable email alerts
            </label>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Email Recipients
            </label>
            <input
              type="text"
              placeholder="admin@example.com, alerts@example.com"
              className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <p className="mt-1 text-xs text-gray-400">
              Separate multiple email addresses with commas
            </p>
          </div>
          
          <div className="flex items-center">
            <input
              id="webhook-alerts"
              type="checkbox"
              className="h-4 w-4 text-blue-600 rounded border-gray-600 focus:ring-blue-500 bg-gray-700"
            />
            <label htmlFor="webhook-alerts" className="ml-2 text-sm text-gray-300">
              Enable webhook notifications
            </label>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Webhook URL
            </label>
            <input
              type="text"
              placeholder="https://example.com/api/webhooks/stream-alerts"
              className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 px-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Alert Triggers
            </label>
            <div className="space-y-2">
              <div className="flex items-center">
                <input
                  id="alert-stream-start"
                  type="checkbox"
                  defaultChecked
                  className="h-4 w-4 text-blue-600 rounded border-gray-600 focus:ring-blue-500 bg-gray-700"
                />
                <label htmlFor="alert-stream-start" className="ml-2 text-sm text-gray-300">
                  Stream started
                </label>
              </div>
              <div className="flex items-center">
                <input
                  id="alert-stream-end"
                  type="checkbox"
                  defaultChecked
                  className="h-4 w-4 text-blue-600 rounded border-gray-600 focus:ring-blue-500 bg-gray-700"
                />
                <label htmlFor="alert-stream-end" className="ml-2 text-sm text-gray-300">
                  Stream ended
                </label>
              </div>
              <div className="flex items-center">
                <input
                  id="alert-stream-error"
                  type="checkbox"
                  defaultChecked
                  className="h-4 w-4 text-blue-600 rounded border-gray-600 focus:ring-blue-500 bg-gray-700"
                />
                <label htmlFor="alert-stream-error" className="ml-2 text-sm text-gray-300">
                  Stream error
                </label>
              </div>
              <div className="flex items-center">
                <input
                  id="alert-high-cpu"
                  type="checkbox"
                  defaultChecked
                  className="h-4 w-4 text-blue-600 rounded border-gray-600 focus:ring-blue-500 bg-gray-700"
                />
                <label htmlFor="alert-high-cpu" className="ml-2 text-sm text-gray-300">
                  High CPU usage
                </label>
              </div>
              <div className="flex items-center">
                <input
                  id="alert-low-bitrate"
                  type="checkbox"
                  defaultChecked
                  className="h-4 w-4 text-blue-600 rounded border-gray-600 focus:ring-blue-500 bg-gray-700"
                />
                <label htmlFor="alert-low-bitrate" className="ml-2 text-sm text-gray-300">
                  Low stream bitrate
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex justify-end">
        <button className="flex items-center px-4 py-2 bg-blue-600 rounded-lg text-white font-medium hover:bg-blue-700 transition-colors">
          <Save className="mr-2 h-4 w-4" />
          Save Changes
        </button>
      </div>
    </div>
  );
};

export default Settings;