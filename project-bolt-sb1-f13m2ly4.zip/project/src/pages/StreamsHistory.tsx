import React, { useState } from 'react';
import { Search, Filter, Download, Trash2 } from 'lucide-react';
import { mockStreams } from '../utils/mockData';

const StreamsHistory: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [protocolFilter, setProtocolFilter] = useState('all');
  
  const filteredStreams = mockStreams
    .filter(stream => 
      stream.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      stream.sourceUrl.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .filter(stream => statusFilter === 'all' || stream.status === statusFilter)
    .filter(stream => 
      protocolFilter === 'all' || 
      (protocolFilter === 'rtmp-rtsp' && stream.sourceProtocol === 'rtmp' && stream.targetProtocol === 'rtsp') ||
      (protocolFilter === 'rtsp-rtmp' && stream.sourceProtocol === 'rtsp' && stream.targetProtocol === 'rtmp')
    );
  
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Stream History</h1>
      
      <div className="bg-gray-800 rounded-lg overflow-hidden mb-6">
        <div className="p-4 flex flex-wrap items-center gap-4">
          <div className="relative flex-1 min-w-[240px]">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
            <input
              type="text"
              placeholder="Search streams..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-gray-700 border border-gray-600 rounded-lg py-2 pl-10 pr-4 text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          
          <div className="flex items-center gap-2 min-w-[200px]">
            <Filter className="h-4 w-4 text-gray-400" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="bg-gray-700 border border-gray-600 rounded py-1.5 px-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="idle">Idle</option>
              <option value="converting">Converting</option>
              <option value="error">Error</option>
            </select>
          </div>
          
          <div className="flex items-center gap-2 min-w-[200px]">
            <Filter className="h-4 w-4 text-gray-400" />
            <select
              value={protocolFilter}
              onChange={(e) => setProtocolFilter(e.target.value)}
              className="bg-gray-700 border border-gray-600 rounded py-1.5 px-3 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
            >
              <option value="all">All Conversions</option>
              <option value="rtmp-rtsp">RTMP → RTSP</option>
              <option value="rtsp-rtmp">RTSP → RTMP</option>
            </select>
          </div>
          
          <button className="ml-auto flex items-center px-3 py-1.5 bg-gray-700 hover:bg-gray-600 rounded text-sm transition-colors">
            <Download className="h-4 w-4 mr-1" />
            Export
          </button>
        </div>
      </div>
      
      <div className="bg-gray-800 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-850 border-b border-gray-700">
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-300">Name</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-300">Conversion</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-300">Source URL</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-300">Status</th>
                <th className="px-4 py-3 text-left text-sm font-medium text-gray-300">Created</th>
                <th className="px-4 py-3 text-right text-sm font-medium text-gray-300">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700">
              {filteredStreams.length > 0 ? (
                filteredStreams.map((stream) => (
                  <tr key={stream.id} className="hover:bg-gray-750 transition-colors">
                    <td className="px-4 py-3 text-sm font-medium">{stream.name}</td>
                    <td className="px-4 py-3 text-sm">
                      <span className="px-2 py-1 bg-gray-700 rounded text-xs">
                        {stream.sourceProtocol.toUpperCase()} → {stream.targetProtocol.toUpperCase()}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm font-mono text-gray-400 truncate max-w-[240px]">
                      {stream.sourceUrl}
                    </td>
                    <td className="px-4 py-3 text-sm">
                      {stream.status === 'active' && (
                        <span className="flex items-center text-green-400">
                          <span className="h-2 w-2 rounded-full bg-green-400 mr-2"></span>
                          Active
                        </span>
                      )}
                      {stream.status === 'idle' && (
                        <span className="flex items-center text-gray-400">
                          <span className="h-2 w-2 rounded-full bg-gray-400 mr-2"></span>
                          Idle
                        </span>
                      )}
                      {stream.status === 'converting' && (
                        <span className="flex items-center text-blue-400">
                          <span className="h-2 w-2 rounded-full bg-blue-400 animate-pulse mr-2"></span>
                          Converting
                        </span>
                      )}
                      {stream.status === 'error' && (
                        <span className="flex items-center text-red-400">
                          <span className="h-2 w-2 rounded-full bg-red-400 mr-2"></span>
                          Error
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-400">
                      {stream.createdAt.toLocaleDateString()}
                    </td>
                    <td className="px-4 py-3 text-sm text-right">
                      <button className="text-blue-400 hover:text-blue-300 px-2">View</button>
                      <button className="text-red-400 hover:text-red-300 px-2">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-gray-500">
                    No streams match your search criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        
        <div className="bg-gray-850 border-t border-gray-700 px-4 py-3 flex items-center justify-between">
          <div className="text-sm text-gray-400">
            Showing <span className="font-medium">{filteredStreams.length}</span> of <span className="font-medium">{mockStreams.length}</span> streams
          </div>
          
          <div className="flex space-x-1">
            <button className="px-3 py-1 bg-gray-700 rounded text-sm hover:bg-gray-600 transition-colors">
              Previous
            </button>
            <button className="px-3 py-1 bg-blue-600 rounded text-sm hover:bg-blue-700 transition-colors">
              1
            </button>
            <button className="px-3 py-1 bg-gray-700 rounded text-sm hover:bg-gray-600 transition-colors">
              2
            </button>
            <button className="px-3 py-1 bg-gray-700 rounded text-sm hover:bg-gray-600 transition-colors">
              Next
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default StreamsHistory;