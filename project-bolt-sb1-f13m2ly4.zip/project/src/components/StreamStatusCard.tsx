import React from 'react';
import { PlayCircle, PauseCircle, AlertCircle, Copy, ExternalLink } from 'lucide-react';
import { StreamConfig } from '../types/stream';

interface StreamStatusCardProps {
  stream: StreamConfig;
}

const StreamStatusCard: React.FC<StreamStatusCardProps> = ({ stream }) => {
  const handleCopyUrl = () => {
    if (stream.targetUrl) {
      navigator.clipboard.writeText(stream.targetUrl);
      // In a real app, we'd show a toast notification here
    }
  };

  const getStatusIndicator = () => {
    switch (stream.status) {
      case 'active':
        return (
          <div className="flex items-center text-green-400">
            <PlayCircle className="mr-1 h-4 w-4" />
            <span>Active</span>
          </div>
        );
      case 'converting':
        return (
          <div className="flex items-center text-blue-400">
            <div className="mr-1 h-3 w-3 rounded-full bg-blue-400 animate-pulse"></div>
            <span>Converting</span>
          </div>
        );
      case 'error':
        return (
          <div className="flex items-center text-red-400">
            <AlertCircle className="mr-1 h-4 w-4" />
            <span>Error</span>
          </div>
        );
      default:
        return (
          <div className="flex items-center text-gray-400">
            <PauseCircle className="mr-1 h-4 w-4" />
            <span>Idle</span>
          </div>
        );
    }
  };

  return (
    <div className="bg-gray-900 border border-gray-800 rounded-lg overflow-hidden">
      <div className="p-4">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="font-medium">{stream.name}</h3>
            <div className="mt-1 text-sm text-gray-400">
              {getStatusIndicator()}
            </div>
          </div>
          <div className="px-2 py-1 bg-gray-800 rounded text-xs font-medium">
            {stream.sourceProtocol.toUpperCase()} → {stream.targetProtocol.toUpperCase()}
          </div>
        </div>
        
        <div className="mt-4 space-y-2">
          <div className="bg-gray-950 p-2 rounded text-sm font-mono overflow-x-auto">
            <div className="text-xs text-gray-500 mb-1">Source:</div>
            {stream.sourceUrl}
          </div>
          
          {stream.targetUrl && (
            <div className="bg-gray-950 p-2 rounded text-sm font-mono overflow-x-auto relative group">
              <div className="text-xs text-gray-500 mb-1">Target:</div>
              <div className="pr-16">{stream.targetUrl}</div>
              <div className="absolute right-2 top-1/2 transform -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity flex space-x-1">
                <button 
                  onClick={handleCopyUrl}
                  className="p-1 hover:bg-gray-800 rounded transition-colors"
                  title="Copy URL"
                >
                  <Copy className="h-4 w-4 text-blue-400" />
                </button>
                <a 
                  href="#" 
                  className="p-1 hover:bg-gray-800 rounded transition-colors"
                  title="Open stream"
                >
                  <ExternalLink className="h-4 w-4 text-blue-400" />
                </a>
              </div>
            </div>
          )}
        </div>
        
        {stream.status === 'active' && (
          <div className="mt-4 grid grid-cols-3 gap-2 text-center text-xs">
            <div className="bg-gray-800 p-2 rounded">
              <div className="text-gray-400">Bitrate</div>
              <div className="font-medium">2.5 Mbps</div>
            </div>
            <div className="bg-gray-800 p-2 rounded">
              <div className="text-gray-400">Resolution</div>
              <div className="font-medium">1080p</div>
            </div>
            <div className="bg-gray-800 p-2 rounded">
              <div className="text-gray-400">FPS</div>
              <div className="font-medium">30</div>
            </div>
          </div>
        )}
        
        {stream.status === 'error' && stream.error && (
          <div className="mt-4 bg-red-900/20 border border-red-900 p-2 rounded text-xs text-red-400">
            {stream.error}
          </div>
        )}
      </div>
      
      <div className="border-t border-gray-800 px-4 py-2 flex justify-between items-center bg-gray-850">
        <div className="text-xs text-gray-500">
          {stream.status === 'active' 
            ? `Uptime: ${Math.floor(Math.random() * 24)}h ${Math.floor(Math.random() * 60)}m` 
            : `Created: ${stream.createdAt.toLocaleString()}`}
        </div>
        <div className="flex space-x-1">
          <button className="px-2 py-1 bg-blue-500 hover:bg-blue-600 text-white text-xs rounded transition-colors">
            {stream.status === 'active' ? 'Stop' : stream.status === 'converting' ? 'Cancel' : 'Start'}
          </button>
          <button className="px-2 py-1 bg-gray-700 hover:bg-gray-600 text-xs rounded transition-colors">
            Edit
          </button>
        </div>
      </div>
    </div>
  );
};

export default StreamStatusCard;