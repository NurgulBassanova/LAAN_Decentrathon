import React from 'react';
import { Bell, User, Search } from 'lucide-react';

const TopBar: React.FC = () => {
  return (
    <div className="h-16 border-b border-gray-800 bg-gray-950 flex items-center justify-between px-4">
      <div className="flex items-center w-96">
        <div className="relative w-full">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
          <input
            type="text"
            placeholder="Search streams..."
            className="w-full bg-gray-800 border border-gray-700 rounded-lg py-2 pl-10 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 text-gray-300"
          />
        </div>
      </div>
      
      <div className="flex items-center space-x-4">
        <button className="relative p-2 rounded-lg hover:bg-gray-800 transition-colors">
          <Bell className="h-5 w-5 text-gray-400" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-blue-500 rounded-full"></span>
        </button>
        
        <div className="flex items-center space-x-3 border-l border-gray-800 pl-4">
          <span className="text-sm font-medium">Admin User</span>
          <div className="h-8 w-8 rounded-full bg-gray-700 flex items-center justify-center">
            <User className="h-4 w-4 text-gray-300" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default TopBar;