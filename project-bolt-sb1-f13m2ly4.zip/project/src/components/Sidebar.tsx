import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Repeat, 
  History, 
  Settings as SettingsIcon,
  Camera
} from 'lucide-react';

const Sidebar: React.FC = () => {
  return (
    <div className="w-64 bg-gray-950 border-r border-gray-800 h-full flex flex-col">
      <div className="p-4 border-b border-gray-800">
        <div className="flex items-center space-x-2">
          <Camera className="h-6 w-6 text-blue-500" />
          <h1 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
            StreamFlow
          </h1>
        </div>
        <p className="text-xs text-gray-400 mt-1">RTMP/RTSP Converter</p>
      </div>
      
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          <li>
            <NavLink 
              to="/" 
              end
              className={({ isActive }) => 
                `flex items-center p-2 rounded-lg transition-all duration-200 ${
                  isActive 
                    ? 'bg-gray-800 text-blue-400' 
                    : 'text-gray-400 hover:bg-gray-800 hover:text-white'
                }`
              }
            >
              <LayoutDashboard className="mr-2 h-5 w-5" />
              Dashboard
            </NavLink>
          </li>
          <li>
            <NavLink 
              to="/converter" 
              className={({ isActive }) => 
                `flex items-center p-2 rounded-lg transition-all duration-200 ${
                  isActive 
                    ? 'bg-gray-800 text-blue-400' 
                    : 'text-gray-400 hover:bg-gray-800 hover:text-white'
                }`
              }
            >
              <Repeat className="mr-2 h-5 w-5" />
              Stream Converter
            </NavLink>
          </li>
          <li>
            <NavLink 
              to="/history" 
              className={({ isActive }) => 
                `flex items-center p-2 rounded-lg transition-all duration-200 ${
                  isActive 
                    ? 'bg-gray-800 text-blue-400' 
                    : 'text-gray-400 hover:bg-gray-800 hover:text-white'
                }`
              }
            >
              <History className="mr-2 h-5 w-5" />
              Stream History
            </NavLink>
          </li>
          <li>
            <NavLink 
              to="/settings" 
              className={({ isActive }) => 
                `flex items-center p-2 rounded-lg transition-all duration-200 ${
                  isActive 
                    ? 'bg-gray-800 text-blue-400' 
                    : 'text-gray-400 hover:bg-gray-800 hover:text-white'
                }`
              }
            >
              <SettingsIcon className="mr-2 h-5 w-5" />
              Settings
            </NavLink>
          </li>
        </ul>
      </nav>
      
      <div className="p-4 border-t border-gray-800">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 rounded-full bg-green-500"></div>
            <span className="text-sm text-gray-400">Server Online</span>
          </div>
          <span className="text-xs text-gray-500">v1.0.0</span>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;