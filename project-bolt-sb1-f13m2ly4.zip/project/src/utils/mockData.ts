import { StreamConfig } from '../types/stream';

// Generate random dates within the last month
const getRandomDate = (daysAgo: number = 30) => {
  const date = new Date();
  date.setDate(date.getDate() - Math.floor(Math.random() * daysAgo));
  return date;
};

export const mockStreams: StreamConfig[] = [
  {
    id: '1',
    name: 'Main Camera Feed',
    sourceUrl: 'rtmp://source.example.com/live/main-camera',
    sourceProtocol: 'rtmp',
    targetProtocol: 'rtsp',
    targetUrl: 'rtsp://stream.example.com:8554/live/main-camera',
    status: 'active',
    createdAt: getRandomDate(7),
    lastActive: new Date()
  },
  {
    id: '2',
    name: 'Secondary Camera',
    sourceUrl: 'rtsp://10.0.0.15:554/stream2',
    sourceProtocol: 'rtsp',
    targetProtocol: 'rtmp',
    targetUrl: 'rtmp://stream.example.com/live/secondary',
    status: 'active',
    createdAt: getRandomDate(14),
    lastActive: new Date()
  },
  {
    id: '3',
    name: 'Conference Room',
    sourceUrl: 'rtmp://source.example.com/live/conference',
    sourceProtocol: 'rtmp',
    targetProtocol: 'rtsp',
    targetUrl: 'rtsp://stream.example.com:8554/live/conference',
    status: 'idle',
    createdAt: getRandomDate(21)
  },
  {
    id: '4',
    name: 'Outdoor Camera',
    sourceUrl: 'rtsp://192.168.1.100:554/outdoor',
    sourceProtocol: 'rtsp',
    targetProtocol: 'rtmp',
    targetUrl: 'rtmp://stream.example.com/live/outdoor',
    status: 'error',
    createdAt: getRandomDate(5),
    error: 'Connection refused: Source stream not available'
  },
  {
    id: '5',
    name: 'Lobby Stream',
    sourceUrl: 'rtmp://source.example.com/live/lobby',
    sourceProtocol: 'rtmp',
    targetProtocol: 'rtsp',
    status: 'converting',
    createdAt: new Date()
  },
  {
    id: '6',
    name: 'Production Line',
    sourceUrl: 'rtsp://10.0.0.25:554/production',
    sourceProtocol: 'rtsp',
    targetProtocol: 'rtmp',
    targetUrl: 'rtmp://stream.example.com/live/production',
    status: 'idle',
    createdAt: getRandomDate(30)
  },
  {
    id: '7',
    name: 'Warehouse Cam',
    sourceUrl: 'rtmp://source.example.com/live/warehouse',
    sourceProtocol: 'rtmp',
    targetProtocol: 'rtsp',
    targetUrl: 'rtsp://stream.example.com:8554/live/warehouse',
    status: 'idle',
    createdAt: getRandomDate(12)
  }
];